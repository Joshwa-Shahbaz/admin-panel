    // ========= code for nav-bar =========
     $(".btn").click(function(){
        $(".menu-two").hide();
        $(".menu").css("display", "block");
        $('.container').css("float", "right");
        $('.container').css({'width':'1110px'});
        $('.noti').css({'margin-left':'400px'});
        $('.content').css({'width':'1105px'});
        $('.content').css({'margin-left':'240px'});
        $('.content h1').css({"padding":'10px 0 0 10px'});
        $('.box').css({'margin-left':'250px'});
        $('.box , .box2 , .box3 , .box4').css({'width':'240px'});
        $('.scale').css({'margin-left':'250px'});
        $('.scale').css({'width':'680px'});
        $('.circle').css({'width':'360px'});
        $('.circle').css({'margin-left':'10px'});
        $('.dash-color').css({'margin-left':'250px'});
        $('.circle-buttons').css({'margin-left':'250px'})
        $('.Split-Buttons-with-Icon').css({'margin-right':'0px'})
        $('.dashtext').css({'margin-right':'100px'})
        $('.brand-buttons').css({'margin-left':'250px'});
        $('.container').css({'margin-right':'2px'});
        $('.card').css({'margin-left':'250px'});
        $('.card3').css({'margin-left':'250px'});
        $('.custom-text-color').css({'margin-left':'250px'});
        $('.Custom-Grayscale-Background-Utilities').css({'margin-right':'10px'})
        $('.border').css({'margin-left':'250px'});
        $('.border').css({'width':'520px'});
        $('.border-bottom').css({'width':'520px'});
        $('.border-bottom').css({'margin-right':'40px'});
        $('.animation').css({'margin-left':'240px'});
      });
      $(".open").click(function(){
        $(".menu-two").show();
        $(".menu").css("display", "none");
        $('.container').css("float", "left");
        $('.container').css("width", "1244px");
        $('.noti').css({'margin-left':'520px'});
        $('.content').css({'margin-left':'110px'});
        $('.content').css({'width':'1238px'});
        $('.box').css({'margin-left':'120px'});
        $('.box , .box2 , .box3 , .box4').css({'width':'280px'});
        $('.scale').css({'margin-left':'120px'});
        $('.scale').css({'width':'750px'});
        $('.circle').css({'width':'400px'});
        $('.dash-color').css({'margin-left':'120px'});
        $('.circle-buttons').css({'margin-left':'120px'})
        $('.Split-Buttons-with-Icon').css({'margin-right':'120px'})
        $('.dashtext').css({'margin-right':'200px'})
        $('.brand-buttons').css({'margin-left':'120px'});
        $('.card').css({'margin-left':'120px'});
        $('.card3').css({'margin-left':'120px'});
        $('.custom-text-color').css({'margin-left':'120px'});
        $('.Custom-Grayscale-Background-Utilities').css({'margin-right':'140px'})
        $('.border').css({'margin-left':'120px'});
        $('.border').css({'width':'560px'});
        $('.border-bottom').css({'width':'560px'});
        $('.border-bottom').css({'margin-right':'80px'});
        $('.animation').css({'margin-left':'120px'});

      });
 
      // javascript for dropdown

      $(".dropdown-icon").click(function(){
        $(".dropdown").toggle();
        $(".dropdown").css("display", "block !important");
      });
      $(".dropdown-icon2").click(function(){
        $(".dropdown2").toggle();
        $(".dropdown2").css("display", "block !important");
      });
      $(".dropdown-icon3").click(function(){
        $(".dropdown3").toggle();
        $(".dropdown3").css("display", "block !important");
      });
